function executeMe()
{
	document.getElementById("nume").innerHTML = "Inginer Software Cosmin Irimiciuc";
	document.getElementById("tDiscipline").innerHTML= "Realizari: ";
	document.getElementById("r0").innerHTML= "Realizarea";
	document.getElementById("p0").innerHTML= "Perioada";
	document.getElementById("r1").innerHTML= "Cea mai buna lucrare de licenta";
	document.getElementById("p1").innerHTML= "Anul 4";
	document.getElementById("lnk1").href= "https://etti.utcluj.ro/files/Acasa/Site/finalizare-studii/Sesiune%20iulie%202024/Cele%20mai%20bune%20proiecte/COMISIA%201%20Cea%20mai%20buna%20lucrare%20de%20licenta_disertatie%20IULIE%202024.pdf";
	document.getElementById("r2").innerHTML= "Internship la o companie";
	document.getElementById("p2").innerHTML= "Anul 3";
	document.getElementById("lnk2").href= "https://etti.utcluj.ro/practica.html";
	document.getElementById("r3").innerHTML= "Realizare studiu individual";
	document.getElementById("p3").innerHTML= "Anul 3";
	document.getElementById("lnk3").href= "https://etti.utcluj.ro/publicatii.html";
	let image=document.getElementById("profil");
	image.src= "img_Profil.jpg";
	image.style.opacity=1;
	document.getElementById("bg").style.background-color=yellow;
	document.getElementsByClassName("text").style.color=red;
	
}